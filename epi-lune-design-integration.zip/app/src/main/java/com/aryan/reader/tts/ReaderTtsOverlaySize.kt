package com.aryan.reader.tts

import android.content.Context
import androidx.core.content.edit
import com.aryan.reader.shared.readerTtsOverlayAlignmentBias as sharedReaderTtsOverlayAlignmentBias
import com.aryan.reader.shared.readerTtsOverlayAlternativeSizes as sharedReaderTtsOverlayAlternativeSizes
import com.aryan.reader.shared.resolveReaderTtsOverlaySize as sharedResolveReaderTtsOverlaySize
import com.aryan.reader.shared.readerTtsChunkLabel

/** Compatibility alias for Android call sites; the state contract lives in shared. */
typealias ReaderTtsOverlaySize = com.aryan.reader.shared.ReaderTtsOverlaySize

private const val READER_PREFS_NAME = "reader_prefs"
private const val READER_TTS_OVERLAY_SIZE_KEY = "reader_tts_overlay_size"

internal fun readerTtsOverlayAlignmentBias(size: ReaderTtsOverlaySize): Float {
    return sharedReaderTtsOverlayAlignmentBias(size)
}

internal fun readerTtsOverlayAlternativeSizes(size: ReaderTtsOverlaySize): List<ReaderTtsOverlaySize> {
    return sharedReaderTtsOverlayAlternativeSizes(size)
}

internal fun resolveReaderTtsOverlaySize(savedName: String?): ReaderTtsOverlaySize {
    return sharedResolveReaderTtsOverlaySize(savedName)
}

internal fun loadReaderTtsOverlaySize(context: Context): ReaderTtsOverlaySize {
    val prefs = context.getSharedPreferences(READER_PREFS_NAME, Context.MODE_PRIVATE)
    return resolveReaderTtsOverlaySize(prefs.getString(READER_TTS_OVERLAY_SIZE_KEY, null))
}

internal fun saveReaderTtsOverlaySize(context: Context, size: ReaderTtsOverlaySize) {
    val prefs = context.getSharedPreferences(READER_PREFS_NAME, Context.MODE_PRIVATE)
    prefs.edit { putString(READER_TTS_OVERLAY_SIZE_KEY, size.name) }
}


