package com.aryan.reader.pdf

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.net.toUri
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.util.UnstableApi
import com.aryan.reader.MainViewModel
import com.aryan.reader.R
import com.aryan.reader.cardTitle
import com.aryan.reader.data.RecentFileItem
import com.aryan.reader.data.getUri
import com.aryan.reader.shared.PdfSplitOrientation
import com.aryan.reader.shared.PdfSplitPane
import com.aryan.reader.shared.PdfSplitPaneState
import com.aryan.reader.shared.PdfSplitWorkspaceState
import com.aryan.reader.shared.PdfSplitPresentation
import com.aryan.reader.shared.DefaultPdfSplitDividerFraction
import com.aryan.reader.shared.MaximumPdfSplitDividerFraction
import com.aryan.reader.shared.MinimumPdfSplitDividerFraction
import com.aryan.reader.shared.PdfSplitDividerDragState
import com.aryan.reader.shared.pdfSplitDividerFractionAtAbsolutePosition
import com.aryan.reader.shared.resolveLayout
import com.aryan.reader.shared.samePdfDocument
import com.aryan.reader.tts.TtsController
import com.aryan.reader.tts.rememberTtsController
import kotlin.math.abs

private val PdfSplitDividerTouchTarget = 20.dp
private val PdfSplitDividerVisualThickness = 3.dp
private val PdfSplitDividerHandleWidth = 4.dp
private val PdfSplitDividerHandleHeight = 34.dp
private val PdfSplitMinPaneWidth = 280.dp
private val PdfSplitMinPaneHeight = 320.dp
private const val PdfSplitDoubleTapTimeoutMillis = 300L

@RequiresApi(Build.VERSION_CODES.VANILLA_ICE_CREAM)
@androidx.compose.material3.ExperimentalMaterial3Api
@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun PdfSplitReaderScreen(
    workspace: PdfSplitWorkspaceState,
    availablePdfs: List<RecentFileItem>,
    isProUser: Boolean,
    usePdfFileNameAsDisplayName: Boolean,
    viewModel: MainViewModel,
    onFocusPane: (PdfSplitPane, Long) -> Unit,
    onClosePane: (PdfSplitPane, Long) -> Unit,
    onCloseWorkspace: () -> Unit,
    onSwapPanes: () -> Unit,
    onDividerChange: (Float, PdfSplitOrientation, Long) -> Unit,
    onOpenDocument: (String, PdfSplitPane, Long?, Long) -> Unit,
    onNavigateToPro: () -> Unit,
) {
    var showDocumentPicker by rememberSaveable { mutableStateOf(false) }
    var pickerTarget by rememberSaveable { mutableStateOf(PdfSplitPane.SECONDARY) }
    var pickerTargetSessionId by rememberSaveable { mutableStateOf<Long?>(null) }
    var pickerTargetRevision by rememberSaveable { mutableStateOf(0L) }
    val ttsController = rememberTtsController()
    val ttsState by ttsController.ttsState.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current
    var isAppActive by remember {
        mutableStateOf(lifecycleOwner.lifecycle.currentState == Lifecycle.State.RESUMED)
    }

    DisposableEffect(ttsController) {
        onDispose {
            ttsController.stop()
        }
    }
    DisposableEffect(lifecycleOwner, ttsController) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> isAppActive = true
                Lifecycle.Event.ON_PAUSE,
                Lifecycle.Event.ON_STOP -> {
                    isAppActive = false
                    if (event == Lifecycle.Event.ON_STOP) ttsController.stop()
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    fun closePane(pane: PdfSplitPane, sessionId: Long) {
        val document = workspace.pane(pane)
        if (document?.sessionId != sessionId) return
        if (document.bookId == ttsState.bookId) {
            ttsController.stop()
        }
        onClosePane(pane, sessionId)
    }

    fun focusPane(pane: PdfSplitPane, sessionId: Long) {
        val document = workspace.pane(pane)
        if (document?.sessionId != sessionId) return
        if (ttsState.bookId != null && ttsState.bookId != document.bookId) {
            ttsController.stop()
        }
        onFocusPane(pane, sessionId)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        PdfSplitWorkspaceToolbar(
            workspace = workspace,
            onSwapPanes = onSwapPanes,
            onCloseWorkspace = onCloseWorkspace,
            onAddDocument = { targetPane ->
                pickerTarget = targetPane
                pickerTargetSessionId = workspace.pane(targetPane)?.sessionId
                pickerTargetRevision = workspace.revision
                showDocumentPicker = true
            },
            canAddDocument = workspace.primary != null,
            onCloseFocusedPane = {
                workspace.focusedDocument?.let { focusedDocument ->
                    closePane(workspace.focusedPane, focusedDocument.sessionId)
                }
            },
        )

        Box(Modifier.weight(1f).fillMaxWidth()) {
            val primary = workspace.primary
            val secondary = workspace.secondary
            if (primary == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.pdf_split_reader_no_other_documents))
                }
            } else if (secondary == null) {
                PdfSplitDocumentPane(
                    paneId = PdfSplitPane.PRIMARY,
                    document = primary,
                    availablePdfs = availablePdfs,
                    isFocused = workspace.focusedPane == PdfSplitPane.PRIMARY,
                    isProUser = isProUser,
                    viewModel = viewModel,
                    isAppActive = isAppActive,
                    ttsController = ttsController,
                    onFocus = { pane, sessionId -> focusPane(pane, sessionId) },
                    onClose = { pane, sessionId -> closePane(pane, sessionId) },
                    onNavigateToPro = onNavigateToPro,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                PdfSplitPaneLayout(
                    workspace = workspace,
                    onDividerChange = onDividerChange,
                    onFocusPane = { pane ->
                        workspace.pane(pane)?.let { focusPane(pane, it.sessionId) }
                    },
                    first = {
                        PdfSplitDocumentPane(
                            paneId = PdfSplitPane.PRIMARY,
                            document = primary,
                            availablePdfs = availablePdfs,
                            isFocused = workspace.focusedPane == PdfSplitPane.PRIMARY,
                            isProUser = isProUser,
                            viewModel = viewModel,
                            isAppActive = isAppActive,
                            ttsController = ttsController,
                            onFocus = { pane, sessionId -> focusPane(pane, sessionId) },
                            onClose = { pane, sessionId -> closePane(pane, sessionId) },
                            onNavigateToPro = onNavigateToPro,
                            modifier = Modifier.fillMaxSize(),
                        )
                    },
                    second = {
                        PdfSplitDocumentPane(
                            paneId = PdfSplitPane.SECONDARY,
                            document = secondary,
                            availablePdfs = availablePdfs,
                            isFocused = workspace.focusedPane == PdfSplitPane.SECONDARY,
                            isProUser = isProUser,
                            viewModel = viewModel,
                            isAppActive = isAppActive,
                            ttsController = ttsController,
                            onFocus = { pane, sessionId -> focusPane(pane, sessionId) },
                            onClose = { pane, sessionId -> closePane(pane, sessionId) },
                            onNavigateToPro = onNavigateToPro,
                            modifier = Modifier.fillMaxSize(),
                        )
                    },
                )
            }
        }
    }

    if (showDocumentPicker) {
        PdfSplitPdfPicker(
            availablePdfs = availablePdfs.filter { item ->
                val candidate = item.uriString?.let { uri ->
                    PdfSplitPaneState(item.bookId, uri)
                } ?: return@filter false
                val otherPane = when (pickerTarget) {
                    PdfSplitPane.PRIMARY -> workspace.secondary
                    PdfSplitPane.SECONDARY -> workspace.primary
                }
                !candidate.samePdfDocument(otherPane)
            },
            usePdfFileNameAsDisplayName = usePdfFileNameAsDisplayName,
            pickerTitle = if (workspace.isSplit) {
                stringResource(R.string.pdf_split_reader_replace_document)
            } else {
                null
            },
            onDismiss = { showDocumentPicker = false },
            onDocumentSelected = { item ->
                showDocumentPicker = false
                onOpenDocument(
                    item.bookId,
                    pickerTarget,
                    pickerTargetSessionId,
                    pickerTargetRevision,
                )
            },
        )
    }
}

@Composable
private fun PdfSplitWorkspaceToolbar(
    workspace: PdfSplitWorkspaceState,
    onSwapPanes: () -> Unit,
    onCloseWorkspace: () -> Unit,
    onAddDocument: (PdfSplitPane) -> Unit,
    onCloseFocusedPane: () -> Unit,
    canAddDocument: Boolean,
) {
    Surface(
        tonalElevation = 3.dp,
        modifier = Modifier.statusBarsPadding(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .padding(start = 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.pdf_split_reader_title),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            // "+" only matters while one pane is open: it fills the empty slot.
            // With both panes occupied, adding means replacing, so the picker is
            // reached through the pane actions instead.
            if (canAddDocument && !workspace.isSplit) {
                IconButton(
                    onClick = { onAddDocument(PdfSplitPane.SECONDARY) },
                ) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = stringResource(R.string.pdf_split_reader_add_document),
                    )
                }
            }
            if (workspace.isSplit) {
                IconButton(onClick = onSwapPanes) {
                    Icon(
                        Icons.Default.SwapHoriz,
                        contentDescription = stringResource(R.string.pdf_split_reader_swap),
                    )
                }
                // Pane management lives on the workspace bar so pane headers can
                // stay out of the layout and give their space to content.
                IconButton(
                    onClick = onCloseFocusedPane,
                ) {
                    Icon(
                        Icons.Default.RemoveCircleOutline,
                        contentDescription = stringResource(R.string.pdf_split_reader_remove_focused),
                    )
                }
            }
            IconButton(onClick = onCloseWorkspace) {
                Icon(
                    Icons.Default.Close,
                    contentDescription = stringResource(R.string.pdf_split_reader_close),
                )
            }
        }
    }
}

@Composable
private fun PdfSplitPaneLayout(
    workspace: PdfSplitWorkspaceState,
    onDividerChange: (Float, PdfSplitOrientation, Long) -> Unit,
    onFocusPane: (PdfSplitPane) -> Unit,
    first: @Composable () -> Unit,
    second: @Composable () -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val layoutDirection = LocalLayoutDirection.current
        val isRtl = layoutDirection == LayoutDirection.Rtl
        val availableWidth = constraints.maxWidth.coerceAtLeast(0)
        val availableHeight = constraints.maxHeight.coerceAtLeast(0)
        val dividerThicknessPx = with(density) { PdfSplitDividerTouchTarget.roundToPx() }
        val minPaneWidthPx = with(density) { PdfSplitMinPaneWidth.roundToPx() }
        val minPaneHeightPx = with(density) { PdfSplitMinPaneHeight.roundToPx() }
        val plan = workspace.resolveLayout(
            availableWidthPx = availableWidth,
            availableHeightPx = availableHeight,
            minPaneWidthPx = minPaneWidthPx,
            minPaneHeightPx = minPaneHeightPx,
            dividerThicknessPx = dividerThicknessPx,
        )
        var dragState by remember(workspace.revision, plan.orientation) {
            mutableStateOf(PdfSplitDividerDragState(plan.dividerFraction))
        }
        val displayedFraction = dragState.displayedFraction
        val frameWorkspace = workspace.copy(
            dividerFraction = displayedFraction,
            verticalDividerFraction = if (plan.orientation == PdfSplitOrientation.VERTICAL) {
                displayedFraction
            } else {
                workspace.verticalDividerFraction
            },
            horizontalDividerFraction = if (plan.orientation == PdfSplitOrientation.HORIZONTAL) {
                displayedFraction
            } else {
                workspace.horizontalDividerFraction
            },
        )
        val framePlan = frameWorkspace.resolveLayout(
            availableWidthPx = availableWidth,
            availableHeightPx = availableHeight,
            minPaneWidthPx = minPaneWidthPx,
            minPaneHeightPx = minPaneHeightPx,
            dividerThicknessPx = dividerThicknessPx,
        )
        LaunchedEffect(plan.orientation, plan.presentation, plan.firstPaneSizePx, plan.secondPaneSizePx) {
            pdfSplitZoomDiag(
                "split.layout orientation=${plan.orientation} presentation=$plan.presentation " +
                    "rev=${workspace.revision} axis=${availableWidth}x$availableHeight " +
                    "firstPane=${plan.firstPaneSizePx} secondPane=${plan.secondPaneSizePx} " +
                    "dividerFraction=${plan.dividerFraction.diagF()}"
            )
        }
        val dividerColor = MaterialTheme.colorScheme.outlineVariant
        val dividerDescription = stringResource(R.string.pdf_split_reader_divider_desc)
        val dividerDecreaseDescription = stringResource(R.string.pdf_split_reader_divider_decrease)
        val dividerIncreaseDescription = stringResource(R.string.pdf_split_reader_divider_increase)
        val axisSizePx = if (plan.orientation == PdfSplitOrientation.VERTICAL) {
            availableWidth
        } else {
            availableHeight
        }
        val dividerAbsoluteStartPx = if (
            plan.orientation == PdfSplitOrientation.VERTICAL && isRtl
        ) {
            axisSizePx - plan.firstPaneSizePx - dividerThicknessPx
        } else {
            plan.firstPaneSizePx
        }
        val visualDividerOffset = with(density) {
            if (plan.orientation == PdfSplitOrientation.VERTICAL) {
                (if (isRtl) framePlan.secondPaneSizePx else framePlan.firstPaneSizePx).toDp()
            } else {
                framePlan.firstPaneSizePx.toDp()
            }
        }
        val interactionDividerOffset = with(density) {
            if (plan.orientation == PdfSplitOrientation.VERTICAL) {
                (if (isRtl) plan.secondPaneSizePx else plan.firstPaneSizePx).toDp()
            } else {
                plan.firstPaneSizePx.toDp()
            }
        }
        val currentDividerAbsoluteStartPx = rememberUpdatedState(dividerAbsoluteStartPx)
        val dividerSemanticsModifier = Modifier
            .semantics {
                contentDescription = dividerDescription
                progressBarRangeInfo = ProgressBarRangeInfo(
                    current = displayedFraction,
                    range = MinimumPdfSplitDividerFraction..MaximumPdfSplitDividerFraction,
                    steps = 0,
                )
                setProgress { value ->
                    val safe = value.coerceIn(
                        MinimumPdfSplitDividerFraction,
                        MaximumPdfSplitDividerFraction,
                    )
                    dragState = dragState.cancel()
                    onDividerChange(safe, plan.orientation, workspace.revision)
                    true
                }
                customActions = listOf(
                    CustomAccessibilityAction(dividerDecreaseDescription) {
                        val safe = (displayedFraction - 0.05f).coerceIn(
                            MinimumPdfSplitDividerFraction,
                            MaximumPdfSplitDividerFraction,
                        )
                        dragState = dragState.cancel()
                        onDividerChange(safe, plan.orientation, workspace.revision)
                        true
                    },
                    CustomAccessibilityAction(dividerIncreaseDescription) {
                        val safe = (displayedFraction + 0.05f).coerceIn(
                            MinimumPdfSplitDividerFraction,
                            MaximumPdfSplitDividerFraction,
                        )
                        dragState = dragState.cancel()
                        onDividerChange(safe, plan.orientation, workspace.revision)
                        true
                    },
                )
            }

        val dividerPointerModifier = Modifier.pointerInput(
                workspace.revision,
                plan.orientation,
                axisSizePx,
                dividerThicknessPx,
                isRtl,
            ) {
                var lastTapTimeMillis = Long.MIN_VALUE
                awaitEachGesture {
                    val down = awaitFirstDown(
                        requireUnconsumed = false,
                        pass = PointerEventPass.Initial,
                    )
                    val pointerAxis = if (plan.orientation == PdfSplitOrientation.VERTICAL) {
                        down.position.x
                    } else {
                        down.position.y
                    }
                    val pointerAbsoluteAxis = currentDividerAbsoluteStartPx.value + pointerAxis
                    val dividerCenter = currentDividerAbsoluteStartPx.value + dividerThicknessPx / 2f
                    if (abs(pointerAbsoluteAxis - dividerCenter) > dividerThicknessPx / 2f) {
                        return@awaitEachGesture
                    }
                    // Once the pointer lands in the divider target, claim the
                    // stream before either reader pane can cancel it while the
                    // preview changes pane constraints.
                    down.consume()
                    val pointerId = down.id
                    val startPosition = down.position
                    var isDragging = false
                    var didFinish = false
                    pdfSplitZoomDiag(
                        "divider.down downAt=$pointerAxis dividerCenter=$dividerCenter " +
                            "absoluteStart=${currentDividerAbsoluteStartPx.value} orientation=${plan.orientation}"
                    )

                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val change = event.changes.firstOrNull { it.id == pointerId }
                            ?: run {
                                if (isDragging) dragState = dragState.cancel()
                                return@awaitEachGesture
                            }
                        val movedDistance = (change.position - startPosition).getDistance()
                        if (!isDragging && movedDistance > viewConfiguration.touchSlop) {
                            isDragging = true
                            change.consume()
                            pdfSplitZoomDiag("divider.dragStart moved=${movedDistance.diagF()} slop=${viewConfiguration.touchSlop}")
                        }

                        if (isDragging) {
                            change.consume()
                            val absolutePointer = if (plan.orientation == PdfSplitOrientation.VERTICAL) {
                                currentDividerAbsoluteStartPx.value + change.position.x
                            } else {
                                currentDividerAbsoluteStartPx.value + change.position.y
                            }
                            val rawFraction = pdfSplitDividerFractionAtAbsolutePosition(
                                pointerPositionPx = absolutePointer,
                                axisSizePx = axisSizePx,
                                dividerThicknessPx = dividerThicknessPx,
                                isRtl = plan.orientation == PdfSplitOrientation.VERTICAL && isRtl,
                            )
                            dragState = dragState.preview(rawFraction)
                            pdfSplitZoomDiag(
                                "divider.dragPreview rawFraction=${rawFraction.diagF()} " +
                                    "preview=${dragState.previewFraction?.diagF()} absolutePointer=$absolutePointer"
                            )
                        }

                        val isRelease = change.changedToUp() || (
                            !change.pressed && event.type == PointerEventType.Release
                            )
                        if (isRelease) {
                            if (isDragging) {
                                val committed = dragState.commit().committedFraction
                                dragState = dragState.cancel()
                                pdfSplitZoomDiag(
                                    "divider.commit committed=${committed.diagF()} " +
                                        "orientation=${plan.orientation} rev=${workspace.revision}"
                                )
                                onDividerChange(committed, plan.orientation, workspace.revision)
                            } else {
                                val isDoubleTap = lastTapTimeMillis != Long.MIN_VALUE &&
                                    down.uptimeMillis - lastTapTimeMillis in 1..PdfSplitDoubleTapTimeoutMillis
                                if (isDoubleTap) {
                                    dragState = dragState.cancel()
                                    pdfSplitZoomDiag("divider.doubleTap reset fraction=$DefaultPdfSplitDividerFraction")
                                    onDividerChange(
                                        DefaultPdfSplitDividerFraction,
                                        plan.orientation,
                                        workspace.revision,
                                    )
                                    lastTapTimeMillis = Long.MIN_VALUE
                                } else {
                                    pdfSplitZoomDiag("divider.singleTap downAt=$pointerAxis")
                                    lastTapTimeMillis = down.uptimeMillis
                                }
                            }
                            didFinish = true
                            break
                        }
                        if (!change.pressed) {
                            break
                        }
                    }

                    if (!didFinish && isDragging) {
                        dragState = dragState.cancel()
                        pdfSplitZoomDiag("divider.cancel gestureAborted didFinish=$didFinish isDragging=$isDragging")
                    }
                }
            }

        val isDragging = dragState.previewFraction != null
        val handleColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)
        val handleAlpha by animateFloatAsState(
            targetValue = if (isDragging) 1f else 0f,
            animationSpec = spring(dampingRatio = 0.6f),
            label = "splitDividerHandleAlpha",
        )
        val dividerVisualModifier = Modifier.drawBehind {
            val strokeWidth = PdfSplitDividerVisualThickness.toPx()
            if (handleAlpha > 0.01f) {
                val handleWidth = PdfSplitDividerHandleWidth.toPx()
                val handleHeight = PdfSplitDividerHandleHeight.toPx()
                val centerY = size.height / 2f
                val centerX = size.width / 2f
                if (plan.orientation == PdfSplitOrientation.VERTICAL) {
                    drawRoundRect(
                        color = handleColor.copy(alpha = handleAlpha),
                        topLeft = Offset(centerX - handleWidth / 2f, centerY - handleHeight / 2f),
                        size = Size(handleWidth, handleHeight),
                        cornerRadius = CornerRadius(handleWidth / 2f),
                    )
                } else {
                    drawRoundRect(
                        color = handleColor.copy(alpha = handleAlpha),
                        topLeft = Offset(centerX - handleHeight / 2f, centerY - handleWidth / 2f),
                        size = Size(handleHeight, handleWidth),
                        cornerRadius = CornerRadius(handleWidth / 2f),
                    )
                }
            }
            if (plan.orientation == PdfSplitOrientation.VERTICAL) {
                drawLine(
                    color = dividerColor,
                    start = Offset(size.width / 2f, 0f),
                    end = Offset(size.width / 2f, size.height),
                    strokeWidth = strokeWidth,
                )
            } else {
                drawLine(
                    color = dividerColor,
                    start = Offset(0f, size.height / 2f),
                    end = Offset(size.width, size.height / 2f),
                    strokeWidth = strokeWidth,
                )
            }
        }

        val dividerInteractionModifier = dividerSemanticsModifier.then(dividerPointerModifier)

        if (plan.presentation == PdfSplitPresentation.SINGLE) {
            Box(Modifier.fillMaxSize()) {
                if (workspace.focusedPane == PdfSplitPane.PRIMARY) first() else second()
                PdfSplitPaneSwitcher(
                    focusedPane = workspace.focusedPane,
                    onFocusPane = onFocusPane,
                    modifier = Modifier.align(Alignment.TopCenter),
                )
            }
        } else if (plan.orientation == PdfSplitOrientation.VERTICAL) {
            val firstWidth = with(density) { framePlan.firstPaneSizePx.toDp() }
            val secondWidth = with(density) { framePlan.secondPaneSizePx.toDp() }
            // Give the divider an explicit cross-axis size.  `fillMaxHeight()`
            // alone can be measured to the header's intrinsic height by the
            // Row when its siblings contain unconstrained reader content.  A
            // short semantics/pointer node makes the divider impossible to
            // drag from the document area even though the visual layout is
            // side-by-side.
            val dividerHeight = with(density) { availableHeight.toDp() }
            if (isRtl) {
                Box(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxSize()) {
                        Box(Modifier.width(secondWidth).fillMaxHeight()) { second() }
                        Spacer(Modifier.width(PdfSplitDividerTouchTarget).fillMaxHeight())
                        Box(Modifier.width(firstWidth).fillMaxHeight()) { first() }
                    }
                    Box(
                        Modifier
                            .offset(x = visualDividerOffset)
                            .width(PdfSplitDividerTouchTarget)
                            .height(dividerHeight)
                            .then(dividerVisualModifier),
                    )
                    Box(
                        Modifier
                            .offset(x = interactionDividerOffset)
                            .width(PdfSplitDividerTouchTarget)
                            .height(dividerHeight)
                            .then(dividerInteractionModifier),
                    )
                }
            } else {
                Box(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxSize()) {
                        Box(Modifier.width(firstWidth).fillMaxHeight()) { first() }
                        Spacer(Modifier.width(PdfSplitDividerTouchTarget).fillMaxHeight())
                        Box(Modifier.width(secondWidth).fillMaxHeight()) { second() }
                    }
                    Box(
                        Modifier
                            .offset(x = visualDividerOffset)
                            .width(PdfSplitDividerTouchTarget)
                            .height(dividerHeight)
                            .then(dividerVisualModifier),
                    )
                    Box(
                        Modifier
                            .offset(x = interactionDividerOffset)
                            .width(PdfSplitDividerTouchTarget)
                            .height(dividerHeight)
                            .then(dividerInteractionModifier),
                    )
                }
            }
        } else {
            val firstHeight = with(density) { framePlan.firstPaneSizePx.toDp() }
            val secondHeight = with(density) { framePlan.secondPaneSizePx.toDp() }
            val dividerWidth = with(density) { availableWidth.toDp() }
            Box(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.height(firstHeight).fillMaxWidth()) { first() }
                    Spacer(Modifier.height(PdfSplitDividerTouchTarget).fillMaxWidth())
                    Box(Modifier.height(secondHeight).fillMaxWidth()) { second() }
                }
                Box(
                    Modifier
                        .offset(y = visualDividerOffset)
                        .height(PdfSplitDividerTouchTarget)
                        .width(dividerWidth)
                        .then(dividerVisualModifier),
                )
                Box(
                    Modifier
                        .offset(y = interactionDividerOffset)
                        .height(PdfSplitDividerTouchTarget)
                        .width(dividerWidth)
                        .then(dividerInteractionModifier),
                )
            }
        }
    }
}

@Composable
private fun PdfSplitPaneSwitcher(
    focusedPane: PdfSplitPane,
    onFocusPane: (PdfSplitPane) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        tonalElevation = 4.dp,
        shadowElevation = 3.dp,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.padding(8.dp),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.pdf_split_reader_single_pane_fallback),
                style = MaterialTheme.typography.labelMedium,
            )
            PdfSplitPaneSwitchChip(
                selected = focusedPane == PdfSplitPane.PRIMARY,
                label = stringResource(R.string.pdf_split_reader_primary_pane),
                onClick = { onFocusPane(PdfSplitPane.PRIMARY) },
            )
            PdfSplitPaneSwitchChip(
                selected = focusedPane == PdfSplitPane.SECONDARY,
                label = stringResource(R.string.pdf_split_reader_secondary_pane),
                onClick = { onFocusPane(PdfSplitPane.SECONDARY) },
            )
        }
    }
}

@Composable
private fun PdfSplitPaneSwitchChip(
    selected: Boolean,
    label: String,
    onClick: () -> Unit,
) {
    Surface(
        selected = selected,
        onClick = onClick,
        shape = RoundedCornerShape(50),
        color = if (selected) {
            MaterialTheme.colorScheme.secondaryContainer
        } else {
            MaterialTheme.colorScheme.surfaceVariant
        },
        contentColor = if (selected) {
            MaterialTheme.colorScheme.onSecondaryContainer
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        },
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        )
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
@androidx.compose.material3.ExperimentalMaterial3Api
@Composable
private fun PdfSplitDocumentPane(
    paneId: PdfSplitPane,
    document: PdfSplitPaneState,
    availablePdfs: List<RecentFileItem>,
    isFocused: Boolean,
    isProUser: Boolean,
    viewModel: MainViewModel,
    isAppActive: Boolean,
    ttsController: TtsController,
    onFocus: (PdfSplitPane, Long) -> Unit,
    onClose: (PdfSplitPane, Long) -> Unit,
    onNavigateToPro: () -> Unit,
    modifier: Modifier,
) {
    val item = remember(availablePdfs, document.bookId, document.uriString) {
        availablePdfs.firstOrNull {
            it.uriString?.let { uri ->
                PdfSplitPaneState(it.bookId, uri).samePdfDocument(document)
            } == true
        }
    }
    val resolvedPdfUri = item?.getUri() ?: document.uriString.toUri()

    LaunchedEffect(paneId, document.sessionId, document.bookId, isFocused) {
        pdfSplitZoomDiag(
            "pane.composed pane=$paneId sessionId=${document.sessionId} bookId=${document.bookId} " +
                "focused=$isFocused uri=${document.uriString}"
        )
    }
    val paneSessionId = document.sessionId
    DisposableEffect(paneId, paneSessionId) {
        onDispose {
            pdfSplitZoomDiag("pane.disposed pane=$paneId sessionId=$paneSessionId")
        }
    }

    Box(
        modifier = modifier
            .background(
                if (isFocused) {
                    MaterialTheme.colorScheme.surface
                } else {
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                },
            )
            .pointerInput(paneId, document.sessionId) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    pdfSplitZoomDiag(
                        "pane.focusDown pane=$paneId sessionId=${document.sessionId} " +
                            "bookId=${document.bookId} alreadyFocused=$isFocused"
                    )
                    onFocus(paneId, document.sessionId)
                    // Wait for the gesture to end without consuming it so the
                    // reader below keeps full ownership of scroll and taps.
                    waitForUpOrCancellation()
                }
            },
    ) {
        if (item == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.pdf_split_reader_missing_document))
            }
        } else {
                key(paneId, document.canonicalIdentity, document.sessionId) {
                    PdfViewerScreen(
                        pdfUri = resolvedPdfUri,
                        initialPage = item.lastPage,
                        initialBookmarksJson = item.bookmarksJson,
                        isProUser = isProUser,
                        // The pane's reader back arrow removes the pane from the
                        // split workspace (the pane header was removed to give
                        // its space to content).
                        onNavigateBack = { onClose(paneId, document.sessionId) },
                    onSavePosition = viewModel::savePdfReadingPosition,
                    onBookmarksChanged = { bookmarksJson ->
                        viewModel.saveBookmarks(
                            bookId = document.bookId,
                            bookmarksJson = bookmarksJson,
                            documentUri = resolvedPdfUri,
                        )
                    },
                    onNavigateToPro = onNavigateToPro,
                    viewModel = viewModel,
                    ttsControllerOverride = ttsController,
                    isPaneAppActive = isAppActive,
                    pane = PdfViewerPane(
                        bookId = document.bookId,
                        pdfUri = resolvedPdfUri,
                        sessionId = document.sessionId,
                        initialPage = item.lastPage,
                        initialBookmarksJson = item.bookmarksJson,
                    ),
                    isPaneFocused = isFocused,
                )
            }
        }
        // Focus is announced with a thin accent edge instead of a full pane
        // header, so the whole pane height stays available for content.
        if (isFocused) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(MaterialTheme.colorScheme.primary),
            )
        }
    }
}

@androidx.compose.material3.ExperimentalMaterial3Api
@Composable
internal fun PdfSplitPdfPicker(
    availablePdfs: List<RecentFileItem>,
    usePdfFileNameAsDisplayName: Boolean,
    pickerTitle: String? = null,
    onDismiss: () -> Unit,
    onDocumentSelected: (RecentFileItem) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
        ) {
            Text(
                text = pickerTitle ?: stringResource(R.string.pdf_split_reader_choose_document),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
            )
            if (availablePdfs.isEmpty()) {
                Text(
                    text = stringResource(R.string.pdf_split_reader_no_other_documents),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                )
            } else {
                LazyColumn {
                    items(availablePdfs, key = { it.bookId }) { item ->
                        ListItem(
                            headlineContent = {
                                Text(
                                    item.cardTitle(usePdfFileNameAsDisplayName),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            },
                            supportingContent = {
                                item.author?.let { author ->
                                    Text(author, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            },
                            modifier = Modifier.clickable { onDocumentSelected(item) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}
